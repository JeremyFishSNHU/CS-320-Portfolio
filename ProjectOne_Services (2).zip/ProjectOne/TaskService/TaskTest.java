package TaskService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {
    @Test public void testTaskCreatedSuccessfully() { Task task = new Task("1234567890", "Homework", "Finish unit testing assignment"); assertEquals("1234567890", task.getTaskId()); assertEquals("Homework", task.getName()); assertEquals("Finish unit testing assignment", task.getDescription()); }
    @Test public void testInvalidTaskId() { assertThrows(IllegalArgumentException.class, () -> new Task(null, "Homework", "Description")); assertThrows(IllegalArgumentException.class, () -> new Task("12345678901", "Homework", "Description")); }
    @Test public void testInvalidName() { assertThrows(IllegalArgumentException.class, () -> new Task("1", null, "Description")); assertThrows(IllegalArgumentException.class, () -> new Task("1", "123456789012345678901", "Description")); }
    @Test public void testInvalidDescription() { assertThrows(IllegalArgumentException.class, () -> new Task("1", "Homework", null)); assertThrows(IllegalArgumentException.class, () -> new Task("1", "Homework", "123456789012345678901234567890123456789012345678901")); }
    @Test public void testSetterValidation() { Task task = new Task("1", "Homework", "Description"); assertThrows(IllegalArgumentException.class, () -> task.setName(null)); assertThrows(IllegalArgumentException.class, () -> task.setDescription(null)); assertThrows(IllegalArgumentException.class, () -> task.setName("123456789012345678901")); assertThrows(IllegalArgumentException.class, () -> task.setDescription("123456789012345678901234567890123456789012345678901")); }
}
