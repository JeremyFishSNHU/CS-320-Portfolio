package TaskService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {
    @Test public void testAddTaskWithUniqueId() { TaskService service = new TaskService(); Task task = new Task("1", "Homework", "Finish assignment"); assertTrue(service.addTask(task)); assertEquals(task, service.getTask("1")); }
    @Test public void testAddDuplicateTaskFails() { TaskService service = new TaskService(); Task t1 = new Task("1", "Homework", "Finish assignment"); Task t2 = new Task("1", "Study", "Study for test"); assertTrue(service.addTask(t1)); assertFalse(service.addTask(t2)); }
    @Test public void testAddNullTaskFails() { assertFalse(new TaskService().addTask(null)); }
    @Test public void testDeleteTask() { TaskService service = new TaskService(); service.addTask(new Task("1", "Homework", "Finish assignment")); assertTrue(service.deleteTask("1")); assertNull(service.getTask("1")); assertFalse(service.deleteTask("1")); }
    @Test public void testUpdateTaskFields() { TaskService service = new TaskService(); service.addTask(new Task("1", "Homework", "Finish assignment")); assertTrue(service.updateTask("1", "Study", "Study for test")); assertEquals("Study", service.getTask("1").getName()); assertEquals("Study for test", service.getTask("1").getDescription()); }
    @Test public void testUpdateMissingTaskFails() { assertFalse(new TaskService().updateTask("99", "Study", "Study for test")); }
}
