package AppointmentService;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;
import org.junit.jupiter.api.Test;

public class AppointmentServiceTest {
    private Date futureDate() { return new Date(System.currentTimeMillis() + 86400000); }
    @Test public void testAddAppointmentWithUniqueId() { AppointmentService service = new AppointmentService(); Appointment appt = new Appointment("1", futureDate(), "Doctor appointment"); assertTrue(service.addAppointment(appt)); assertEquals(appt, service.getAppointment("1")); }
    @Test public void testAddDuplicateAppointmentFails() { AppointmentService service = new AppointmentService(); Appointment a1 = new Appointment("1", futureDate(), "Doctor appointment"); Appointment a2 = new Appointment("1", futureDate(), "Dentist appointment"); assertTrue(service.addAppointment(a1)); assertFalse(service.addAppointment(a2)); }
    @Test public void testAddNullAppointmentFails() { assertFalse(new AppointmentService().addAppointment(null)); }
    @Test public void testDeleteAppointment() { AppointmentService service = new AppointmentService(); service.addAppointment(new Appointment("1", futureDate(), "Doctor appointment")); assertTrue(service.deleteAppointment("1")); assertNull(service.getAppointment("1")); assertFalse(service.deleteAppointment("1")); }
}
