package AppointmentService;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;
import org.junit.jupiter.api.Test;

public class AppointmentTest {
    private Date futureDate() { return new Date(System.currentTimeMillis() + 86400000); }
    private Date pastDate() { return new Date(System.currentTimeMillis() - 86400000); }

    @Test public void testAppointmentCreatedSuccessfully() { Date date = futureDate(); Appointment appt = new Appointment("1234567890", date, "Doctor appointment"); assertEquals("1234567890", appt.getAppointmentId()); assertEquals(date, appt.getAppointmentDate()); assertEquals("Doctor appointment", appt.getDescription()); }
    @Test public void testInvalidAppointmentId() { assertThrows(IllegalArgumentException.class, () -> new Appointment(null, futureDate(), "Description")); assertThrows(IllegalArgumentException.class, () -> new Appointment("12345678901", futureDate(), "Description")); }
    @Test public void testInvalidAppointmentDate() { assertThrows(IllegalArgumentException.class, () -> new Appointment("1", null, "Description")); assertThrows(IllegalArgumentException.class, () -> new Appointment("1", pastDate(), "Description")); }
    @Test public void testInvalidDescription() { assertThrows(IllegalArgumentException.class, () -> new Appointment("1", futureDate(), null)); assertThrows(IllegalArgumentException.class, () -> new Appointment("1", futureDate(), "123456789012345678901234567890123456789012345678901")); }
    @Test public void testSetterValidation() { Appointment appt = new Appointment("1", futureDate(), "Description"); assertThrows(IllegalArgumentException.class, () -> appt.setAppointmentDate(null)); assertThrows(IllegalArgumentException.class, () -> appt.setAppointmentDate(pastDate())); assertThrows(IllegalArgumentException.class, () -> appt.setDescription(null)); assertThrows(IllegalArgumentException.class, () -> appt.setDescription("123456789012345678901234567890123456789012345678901")); }
}
