package ContactService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {
    @Test
    public void testContactCreatedSuccessfully() {
        Contact contact = new Contact("1234567890", "Jeremy", "Fish", "1234567890", "123 Main Street");
        assertEquals("1234567890", contact.getContactId());
        assertEquals("Jeremy", contact.getFirstName());
        assertEquals("Fish", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Main Street", contact.getAddress());
    }

    @Test public void testInvalidContactId() { assertThrows(IllegalArgumentException.class, () -> new Contact(null, "Jeremy", "Fish", "1234567890", "123 Main Street")); assertThrows(IllegalArgumentException.class, () -> new Contact("12345678901", "Jeremy", "Fish", "1234567890", "123 Main Street")); }
    @Test public void testInvalidFirstName() { assertThrows(IllegalArgumentException.class, () -> new Contact("1", null, "Fish", "1234567890", "123 Main Street")); assertThrows(IllegalArgumentException.class, () -> new Contact("1", "LongFirstNm", "Fish", "1234567890", "123 Main Street")); }
    @Test public void testInvalidLastName() { assertThrows(IllegalArgumentException.class, () -> new Contact("1", "Jeremy", null, "1234567890", "123 Main Street")); assertThrows(IllegalArgumentException.class, () -> new Contact("1", "Jeremy", "LongLastNme", "1234567890", "123 Main Street")); }
    @Test public void testInvalidPhone() { assertThrows(IllegalArgumentException.class, () -> new Contact("1", "Jeremy", "Fish", null, "123 Main Street")); assertThrows(IllegalArgumentException.class, () -> new Contact("1", "Jeremy", "Fish", "12345", "123 Main Street")); assertThrows(IllegalArgumentException.class, () -> new Contact("1", "Jeremy", "Fish", "12345abcde", "123 Main Street")); }
    @Test public void testInvalidAddress() { assertThrows(IllegalArgumentException.class, () -> new Contact("1", "Jeremy", "Fish", "1234567890", null)); assertThrows(IllegalArgumentException.class, () -> new Contact("1", "Jeremy", "Fish", "1234567890", "1234567890123456789012345678901")); }
    @Test public void testSettersValidateFields() { Contact c = new Contact("1", "Jeremy", "Fish", "1234567890", "123 Main"); assertThrows(IllegalArgumentException.class, () -> c.setFirstName(null)); assertThrows(IllegalArgumentException.class, () -> c.setLastName("LongLastNme")); assertThrows(IllegalArgumentException.class, () -> c.setPhone("123")); assertThrows(IllegalArgumentException.class, () -> c.setAddress("1234567890123456789012345678901")); }
}
