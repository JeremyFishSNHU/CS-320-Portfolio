package ContactService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {
    @Test public void testAddContactWithUniqueId() { ContactService service = new ContactService(); Contact c = new Contact("1", "Jeremy", "Fish", "1234567890", "123 Main"); assertTrue(service.addContact(c)); assertEquals(c, service.getContact("1")); }
    @Test public void testAddDuplicateContactFails() { ContactService service = new ContactService(); Contact c1 = new Contact("1", "Jeremy", "Fish", "1234567890", "123 Main"); Contact c2 = new Contact("1", "John", "Doe", "0987654321", "456 Oak"); assertTrue(service.addContact(c1)); assertFalse(service.addContact(c2)); }
    @Test public void testAddNullContactFails() { assertFalse(new ContactService().addContact(null)); }
    @Test public void testDeleteContact() { ContactService service = new ContactService(); service.addContact(new Contact("1", "Jeremy", "Fish", "1234567890", "123 Main")); assertTrue(service.deleteContact("1")); assertNull(service.getContact("1")); assertFalse(service.deleteContact("1")); }
    @Test public void testUpdateContactFields() { ContactService service = new ContactService(); service.addContact(new Contact("1", "Jeremy", "Fish", "1234567890", "123 Main")); assertTrue(service.updateContact("1", "John", "Doe", "0987654321", "456 Oak")); Contact updated = service.getContact("1"); assertEquals("John", updated.getFirstName()); assertEquals("Doe", updated.getLastName()); assertEquals("0987654321", updated.getPhone()); assertEquals("456 Oak", updated.getAddress()); }
    @Test public void testUpdateMissingContactFails() { assertFalse(new ContactService().updateContact("99", "John", "Doe", "0987654321", "456 Oak")); }
}
